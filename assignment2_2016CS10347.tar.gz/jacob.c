#include "types.h"
#include "stat.h"
#include "user.h"
// #include <math.h>
// #include <stdio.h>
// #include<unistd.h>

// #define N 11
// #define E 0.00001
// #define T 100.0
// #define P 2
// #define L 20000

float fabsm(float a){
	if(a<0)
	return -1*a;
return a;
}

int main(int argc, char *argv[])
{	
	char *filename;
	filename = "assig2a.inp";
	// int size = 100;
	// short arr[size];
	// char c;
	int fd = open(filename, 0);
	int N = 0;
	while(1){
		char c;
		read(fd,&c,sizeof(char));
		int a = c-'0';
		// printf(1,"a is %d\n",a );
		if(a == -38) break;
		N = N*10 + a;
		
	}
	// printf(1,"N is %d\n",N );

	float E = 0.0;
	int bd = 0;
	int co = 0;
	while(1){
		char c;
		read(fd, &c, sizeof(char));
		int a = c-'0';
		if(a == -2)bd = 1;
		// printf(1,"a is %d\n",a );
		if(a==-38){break;}
		if(bd == 1 && a!=-2){
			co++;			
		}
		if(a!=-2)
		E = E*10 + a;	
	}


	for(int k=0; k<co; k++){
		E = E*1.0/10;
	}



	float T = 0.0;
	int bd2 = 0;
	int co2 = 0;
	while(1){
		char c;
		read(fd, &c, sizeof(char));
		int a = c-'0';
		if(a == -2)bd2 = 1;
		// printf(1,"a is %d\n",a );
		if(a==-38){break;}
		if(bd2 == 1 && a!=-2){
			co2++;			
		}
		if(a!=-2)
		T = T*10 + a;	
	}

// printf (1,"T1:%d ", (int)T);
	for(int k=0; k<co2; k++){
		T = T*1.0/10;
	}
// printf (1,"T2:%d ", (int)T);


	// printf(1,"T is %d\n",T );
	int P = 0;
	while(1){
		char c;
		read(fd,&c,sizeof(char));
		int a = c-'0';
		// printf(1,"a is %d\n",a );
		if(a == -38) break;
		P = P*10 + a;	
	}
	// printf(1,"P is %d\n",P );

	int L = 0;
	while(1){
		char c;
		read(fd,&c,sizeof(char));
		int a = c-'0';
		// printf(1,"a is %d\n",a );
		if(a == -38) break;
		L = L*10 + a;	
	}

	// printf(1,"L is %d\n",L );
// printf(1, "params are  %d %f %f %d %d", N,E,T,P,L);




	float diff;
	int i,j;
	float mean;
	float u[N][N];
	float w[N][N];


	int count = 0;
	// int c =0;
	mean = 0.0;
	for (i = 0; i < N; i++){
		u[i][0] = u[i][N-1] = u[0][i] = T;
		u[N-1][i] = 0.0;
		mean += u[i][0] + u[i][N-1] + u[0][i] + u[N-1][i];
	}
	mean /= (4.0 * N);
	for (i = 1; i < N-1; i++ )
		for ( j= 1; j < N-1; j++) u[i][j] = mean;
	
// my code
	int pid;
	int k;
	// printf(" before fork \n");

	int perprocess = N/P;
	diff = 0.0;
	int numi =0;

		int parentpipe[P][2];
		int ret[P];
		for (int i = 0; i < P; ++i)
		{
			ret[i] = pipe(parentpipe[i]);
			if (ret[i] == -1) {
		      printf(1,"Unable to create pipe p  %d \n", i);
		      return 1;
		  	}
		}

	for(;;){
				// if(k==0) printf("in first, start and end are %d  %d\n",start, end);
		numi++;
		diff = 0.0;



		for ( k = 0; k < P; ++k)
		{
			pid = fork();
	        if (pid == 0) {              // child process

	        // read(parentpipe[k][0], diff, sizeof(float));
	        // read(parentpipe[k][0], &u[0], sizeof(u));


	        // printf("we are in process %d \n",k );
	        // close(parentpipe[k][0]);
			int start =  k*perprocess;
			int end  =  start + perprocess;
			if(k == 0) start = 1;
			if(k == P-1) end = N-1;
			
	        for(i =start ; i < end; i++){
				for(j =1 ; j < N-1; j++){
					w[i][j] = ( u[i-1][j] + u[i+1][j]+
						    u[i][j-1] + u[i][j+1])/4.0;
					if( fabsm(w[i][j] - u[i][j]) > diff )
						diff = fabsm(w[i][j]- u[i][j]);	
				}
			}
	// printf(1,"count is %d\n", count);	    
			for (i =start; i< end; i++)	
				for (j =1; j< N-1; j++) u[i][j] = w[i][j];


			write(parentpipe[k][1], &diff, sizeof(float));		
			write(parentpipe[k][1], &u[start], sizeof(u)*(end-start)/N);
			// printf("written in  %d \n",k );

			// close(parentpipe[k][1]);
	        exit();
	        }
		}

		for ( k = 0; k < P; ++k){
			wait();
		}
        //parent
	        int pk ;
	        // float mdiff = -40;
	        float diff1[P];

	        diff = 0.0;
			for ( pk = 0; pk < P; ++pk)
			{
			// close(parentpipe[pk][1]);
			int start =  pk*perprocess;
			int end  =  start + perprocess;
			if(pk == 0) start = 1;
			if(pk == P-1) end = N-1;
			read(parentpipe[pk][0], &diff1[pk], sizeof(float));

			read(parentpipe[pk][0], &u[start], sizeof(u)*(end-start)/N);
			if(diff1[pk]> diff) diff = diff1[pk];	
			// close(parentpipe[pk][0]);
			}
			// diff = mdiff;	

			// if(c <10){			
// printf("diff is %f\n", diff);c++;}
			count++;
			if(diff <= E || count > L){ 
			break;
			}

	}
	// printf(1," numm iteratons is %d\n",numi);

	for(i =0; i <N; i++){
		for(j = 0; j<N; j++)
			printf(1,"%d ",((int)u[i][j]));
		printf(1,"\n");
	}

	exit();

// else{

// 	int pk ;
// 	for ( pk = 0; pk < P; ++pk)
// 	{

// 	int start =  pk*perprocess;
// 	int end  =  start + perprocess;
// 	if(pk == 0) start = 1;
// 	if(pk == P-1) end = N-1;
// 	read(parentpipe[pk][0], &u[start], sizeof(u)*(end-start)/N);	
// 	}
	
// 	for(i =0; i <N; i++){
// 		for(j = 0; j<N; j++)
// 			printf(1,"%d ",((int)u[i][j]));
// 		printf(1,"\n");
// 	}
// 	exit();
// }
	
}
